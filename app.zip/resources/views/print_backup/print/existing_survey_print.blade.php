<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Application For Trade License</title>
</head>

<body>
<table width="100%" border="none">
  <tr>
    <td><img width="121" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAD+AMEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9U6KKKACiiigAooooAKKKKACiikNAAKQkZqPtXiv7RXxft/gz4S0m7m1O30NNQ1RLX+1tR/497ciOS4/ef9dPK8v/ALaVnzmkIe0PcKK5rwb4gHinwpo2s+R5P2+0juPK/ueYM10taGYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUh6UAHBFRZxSA/LmvHvjv8AHW0+DVho0H9mXmr65rE8lvp+m6dH5ktwY/8AIrKpP2ZpTpupP2aPQvFvi7TPB2iSahqd1HZQxj/lrJ5Yr418W/HfSfjv4s/snTde+Hmp6L5nl2eieIJPtEklxH5n+keXXyl8eY/j58ePElz/AGl4F8S2PhyL/jz0SL/Vx/8AxyvMY/2W/ipc3FvD/wAK+1aLzPLj/ex14GLr+09w/QcBkuHp0/aVanvn6OfCb9srwlo+PDWseL9C1e98/Fm+i3H7pI/rJ5fmV9bafqFrrNtHd2k0c0Z+5JHX4Yn9lX4qD/mnup19H/sxeJ/j38Bb+PTNS8Ea9rPhL/nx/wBZJZ/9e9a4fFQpw1mc2ZZLQ5PaYeZ+qgU08jivMfhJ8XdO+L3httX03TdT01Y5Ps8kWpW32c+Z3Hvsr03Jr2/aXPhHDkdh1FFFaCCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAhNfPf7X9jB/wgFlqXkf8TK3e8+yXIH7yA/2deV9CGvCP2xP+STz/S9/9N15XDi/4B24D/e6Z+UHwk0Pxl8T9ct4P+Ek16PSo5I7e7uba5kkuJ5JP+Xe3/ecySV9K/FX9nTWvhX4E0qefTLjxd4rnuP9D8OW15JcXv2f/l5k8yvUv2BvB2l6FYaTdzTgyx6fZx2Zm/1kl5eRfbLz/wAh+VXvP7QQj8LXfgf4kT3iWVt4T1fGoSyyeXH/AGfef6Pc/wDfv93J/wBs6yoYSm6d6h9BmubV1X9nTPkW6/YlfxZ8KfDviO00m/029uII7y80q1k8vUIP+mf7z93ceX718l23g7WvBnxr8KaZrt3JLH/aFncWd75kkltcW/mf6yv3Nsry31C2t7q0n82ykjjMcsf+reOvzW/bE8I6TdeLP7S0meM/Z9c0/Vf3X/LvJeXH2e9j/wC2kkcclGKw9P2f7s6MmzWpVn7Oofov8PP+RK0f/r3j/lXWetc34I/5Fiy/65JXSetdNH+FTPj8R/HqD6KKK6jIKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiikzQA09K+f/2zf+SUj/evP/TdeV9AHpXz7+2V/wAkq/8AA3/03XlcmK/hs7su1xdM8V/YS1zw3ruieHBcW8f22TTreXT5JR+8juLOOOzvP/RdvXtfxRkj+LPj/SvhkLSDU/Dscceq+KPtUfmRfZ/+Xa2/66SSfvP+2dfk78FPizqXwm1C4zaX0ugSyR3HlW37u5s7j/n4t/8ArnX2n4b/AGn9CuvCniM58vUdcvI7y81aP/R7iS4/d+Z+7k/55xx+XHXHhcRT5PZzPbzXKq7rzdOB962NhaaJYW9rZ28cVlBGkcEUf+rSOvzN/bR8b6VbePzpuh28cUcmq2elfuv9XcfZ5Ptl5J/2zkkjjrvfij+3LdnwaNN0K01PzXt4/wB7bWn2i4uP/jdfD8kvijxn4/0XUtS0bUh5clvb2ccdnJ5dvb0YrF03TsjtybKalP8AeVPcP3G8Af8AIqaV/wBc66pu9c14Jj8rw5ZV0rd67KH8KmfHYj+LMfRRRXWZBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQA3r1qI4pScDNeM/Gf8Aaf8AAvwShEOuaqJdak/499F0795e3D+0dYzmo7mkITqfAeyjrjtXyD+2l8RrH4YW+k6r4k0bUtX8Ox3H+j/2TqEdvJbyeX/zz/5aVnW/jL9of48H/iW2ln8GfDHaW5j+2arJH/6LrR039jPwhf6gNS+IOs618QdRkk8zzNb1CSSPzP8Ar3j/AHdfJ5jnuApwnQnM9fCUPq9T2lc+Tbn9sz4W3X/Mk67/AOB9Wov2j/BWoW//ACSLxfLH/wBM7uSSvvKw+E3wz+H2n/uPDWg6PZ/89JI7eOq+rfF/4T+Df3F34o8NWH/b5HXwqzCH/LvDzPqf7Wp/8u4HwjfftC+GLW3/AOSQ+MIvL/563lxHXJ3v7VPgXz/+Sa6nHJ/008QSR1+i1j8ePhBrP/Hv4w8NS+Z/0+Rx1pnwl8OvG4uMab4a1jzPM8zy/s9x5la/2lCH8TDs1hnVP4KkDzv9iXVbvxloVz4oggTSPDmoW/8Aodl/bEl7J5n/AC0k/ef6uvrAHIOOtfJ2ofsZfD4TyXfhttW8CXsn/LXw/eSW0aSf9c6zra0+P/wcz9j1ax+Lmgx/8uWo/wChar5f/XSvsMDxDgZ/uz5HFUIYipOpTmfY/HfNOB49q8A+EP7WnhD4qap/YVx9o8I+L4/9ZoGtx/Z7mveV6V9jTqU6nwM8edOdOfJMnopB0pa2ICiiigAooooAKKKKACiiigAooooAhxjpWZqd9aaPp8t3dzx21lFHmSWT93HHHVbxJ4n03wlolzqerXUVjp1vH5k91LJ5ccYr46k1TxJ+3JrdwP8ASPD/AMD7eT93/wAs7nxB/wDc9efjsZTy+n7SodFChOp77N/Xvj34w/aA1u48N/BuH+zfDkUnlX/j65Q+X/25xnr9an0P4OeG/wBn7RLnWvDfha4+KfjweXJeSS3kcmqyR/8APT95XrcsnhL4MeAPtEk9v4b8MaXH/wBc4446+OfH/wARrv4g/EC9nOm3HgjwfHHZ3PiCP/j317XNC/5/fM/1n2eP/lpHXwWAxGL4gqe0n/APTnOFOHJTPcI/2xfC/ixXs/BOjax4u8T2/mG80ny/s39mf89PtEkn+r8usr9nX4v+Nvi74q8X/wDCR/2bb+HY7Ozj0uTRfM8u4kk8z7RJb3Ekcf8Aq68o8AS3fw+8S3UFp4P8U6Peah5mlaxrem2ckenaPpcf/HlJp3lxyR3FegfCf9lrXvBPxf0rxHdSaDFZ2H2yT7TonmR3F/8AaP8AlnJb/wCrjt/+udLHYHKcBTqQp61DM+evGvhfwv4j+Nlt4Q1Kf/TZPEmo+Hv7J1bULy81G88zTpI7e9k8z935f2jy5I6jisdT8D/CjVrvTPDZl8GeL/hfbyXn9m6XHcRyarHp0lvcSSSf8ufl/wCskr9B/HOl+CALI+J/7Ii+z3Fve29zqMkcckclvJ+7k/ef886+ZPGX7W+k6F4/1rwR4P8AEngDw1oHh+zjKS61+8ttTkk8z/R4/L/5513ZbmlfFKnTp4cXIeMWWvXfw+0vVf7NePw9p2sSaFb6p4kj0v7bJb+X4Vs5La3+z/8ATS4krJ8F6PpvxJ1u3NxbwTar4rv/AA1Hcal4bsv7L/4R+8/efbdO/wCWf+rs7f8AeV9c/BD9r74d/ETT7r+09Z0bw3r9lcRx3lrJef6PJJ/yzuLeT/lpHJXr1jY+EfG2oaNrWm3GmalJpFxJe2cmnXEcmJ7iOSPzP+2kclLF53XoTqU6mHM+Q8q/ac8ZeN/hNb+ELvwRb3A0GzuI4tUkljjuLKzt/wB3/rP+XiqvhP8Aa3Md/q2mfEHQpPCv9j3H9nXniSx8y40H7R/18fu/LrR+Mf7Otv8AED4n6N46EA1L7Hp9xZ3miS3EkdtqknlyfY/+/clfMut/D/xvo/iz+xvtepy3uh+XZah/Yl5JHqN5capJ5l7qtvH/AMtI/M/56VxYHCZZmeF5KmlQ2Ptjx/8ABvwL8b9Et59d0231L935lnq1t+7kj/65yV5Injr4i/skT248U3dx8Rvhb/0G/L/4mOjx/wDTx/z0jrzH4Kax4k8E+Iz4W+FGi63fWWkahJpWqaJr8kn9nSR2/wDrL23vP+WdxJ/zzr7dm0/7Vp9xBd28flyR/vLaT95HXj18RX4XxdOnCpz0y4fvPcqHQ+E/FukeN9EttV0O8i1LTrmPzI7mKTfGa6IgAYNfGM3gfXf2W/Elz4o8CC41L4fXEkkuueEv3kklv/08WdfUngT4g6L8S/Cdl4j8P3cepabcR+ZHLH3r9Oy3M6eY0/aQPNr0PZ+/A66ikFLXsHMFFFFABRRRQAUUUUAISMVCMUAcV80ftefErXNB0nRvh94IA/4TXxpcSWVpL/z523/LxcVhUqQpU/aVDSnTnUnyQPOPiHqGpfti/GO48H6cZIvhL4UuP+J5exny/wC1Lz/n3/7Z19M6FpVpounW+m6baR2OnQR+XbxRR+X5dc38IfhjpPwg8AaX4a0YZhto/wB5Ln57iTvJ/wBtK7qv544izqpmGItT/hntqcFD2cDl/FHgnRfGVtZf2zpsepfZ7iO9tPNjjk8u4/5Zyf8AbOvD/D/7I39n6eNVuvEg1Lxx/bkmo/8ACSXNn+8uLeT/AFllcfvP3kclfTmMkZzXzH8U/jvca54//wCFbeCdTk03UvLuP7R1uOz+0SW/lx/8e9lH/q5Lyuzh2vmWJ58JhPcpmc4I0vE/xp8D/s3+HNF8C2n2jXNe8y3stP8ADdtJHJc+Zcf6uP8A6Z18/wDxY+PnxB1/wCNSuNa1fwheXmqf2VYeF9Ds/LjiuI7j7P8AZ9Q1ST/V+ZVX4b/DSfWfDl7b6louveFfh18R9Ujt/wDj4uP7a0fULf8A1dxcSSf89K+vbH4J2lr4r8XXFxcR6l4d8SW8f9oaJfWcckclxH+7kuP+2kdfcTeW5R/E/eVCvI+NNf8AgxdfCLxJ4V/4S74ff8JDp1v44jjk8da3qEeoR3el3kn2f/SY6zvAFh8StB0P/il9Jk0jxXb/AAzk0qP7NZ/vPM0/xDJbyf8AXS4+z19e6x8W/hp8EfDdv4XbUbf7HZx/u7JP9Ikjrgb39vjwfY/8g/RtRvf9Z+8EX2einxNXnT/dUz3sLw/meMp+0w+HZ5Jq/gTx1feMvh3qsGual8Ro/wCxPEuo+F7PW7OOOXzPsX+jxXn+r8y48ySvPzpWmyfEfVtZ07QbiS6s/wCytGGi3NpJ4a1XUNYvLj7R/o8dnJb+X5dv+8/0ivpi3/4KB+Gs/wClaJqtl/00jHmV1nhT48fCr4i/bv7P1K30jVtQP+lyun2e4kk8vy6IcTVn/vGHDF8N5pg4e0xGHZnfst6p4z1D/hL9TuvGFx4q8CW+oXmneH49WSOS9uPs8n/Hz9s/d+ZHJXa/DP4r+EPHvja6tP7Nl8L/ABAtrPy7vR9Zsvs+ox2+c/8AbSD/AJ5+XW7pvwi8NW3wV/4VnaF/+Edk0iTSh5cn7z7PJHXxJ4k8Bx2uuf2NoWta99i0+8k07wHHreoSR/2feW//AB+6z5n/AD5x152DoYHPsRXtU9mz5+1Snoz7j+F/gfTPAGn6/Bp2o/2tHqGuXmqyS/6zy7if/WR16ERXw18L/jHd2GqeB/Dmh6lpF9Za34r/AORt8N6f5eneII5I5PtP2iP/AJc7yvuLzOdlfFcS5biMvr89SpzhTmhJIweK+VfFMU/7IXxHtvF+ik/8Kl8QXATXNJ/1kel3H/Pxb19VVi+LvDGm+LPDl7outWn23TbyOSO4j/6Z1z5DnVTLKn9wbV/jO203U7TWdPt7qznjubG4jSSCWL95HJHWoelfH/7Heu6l8O/EXiP4HeJJ/OPh/wD03Q72X/l80uSvr4tgZr+jcPXhiacKlM8ipD2c+QsUUg6UtdZkFFFFABRRRQBmX11BYW8s9wfKjjj/AHklfIn7Pkg+NfxX8X/HC7H/ABLpD/Y3hiKX935enx/8vH/bSu0/bj8ZaloXwcPhzQZfL8ReMLyPw7p/l/6z9/8A6z/yHXz7+1v4Z0X4L/C/4d6TceBY/FXhTR/9DkvZNQuLP7HJ/wBs/wDnpXyOe1PacmD5/jPawND2h9s2V9aahb/a7S7jvYpPuSRSeZHWnXgn7H2j6t4c+Cmk6bqc9p+7kkks49NuPtEdvZ/8s4/Mr3bza/Asyw8MHiJ04G1SHs6nsz57/aU+Mdv4IufD3gjSdc/sPxf4ovPs9nfSSeX9jj/66Sfu45JP9XHXy54E0q6sTqvw/wBVgj8I6b/bkdxJZeLNRk/t2w1D/WR3OlRxySeZ5f8Ay0k/5eK9e+Mf7P3xSuPEeu6jps9v420zx5fxad4j0ny47aSz0ePtHcSSV63pXhjwt+zz4c1XUZ9Skm02wjk/s+TVpPtFxpdv/wA+9vcf6zy/+ecdfq+Dx2AyjLKdOn/EqHPSp1MTV9nTgdFq/j20+EHw/ttR8ca7HLe21vGLy9ij8sXdx/0zj/6aV8T/ABM/ai1z4iare6eNck8JeHzHIEt7aOSS5uKqr8Y/DPxF+Jtz4v8Air9ql0u38yPS9Agt5JIo4/8AnpXb+Kvin+zVdeHbyDS/Cs39oSW8kcEn9lyR/vK5MDlNOr/tFSp75+y5RkyyeoljMHOpOf3I8I13wobLSPAo020+06rr1hJcXEfmfvLi48yRK998J/saaTYa74N0nx14vji1nX3kNno1t+7+0Rxx/aJa5f4I2MGs/FX4E/2inMej3En/AEzeT7RJ5devfFXwbdaD+3h8LfiFq2pR6P4Qt9Dk063ubmTy7a3vP3kf2f8A6Z+Z9or6fAYSlUr8lQ5+KuLsyyunTweDn7P4/wD0s858Yfsh6TfeNvHem+CfGEd1qWjzxyS6D5f7yzjkj8yvCIfDyjwP8QY9R04ReIPDlxp8Sfu/3lvJ9s8uSvsHwh4Lvn/b9+IvxE02fzPBcmgCzvLq1/eRyapH5dv9m/6+I/Lrxr9ozTLe18SfHqC3kj+2G38Pfa5Y/wDV/bPtFa4rA06eI9pD4DPhzi7M8xp/UMXU59jB8A/tB6x8MddjPhvVNW1vw/HHGJNK1qPmOSvr3Qr/AOHv7Sfw/wDE+o6dbgXusaJJo2oSxfu9Qgt/L/4968L0D4//AAQ0fQ0trz4SwyXnlx73Gl2n7yT86818RfGbw54c+Itl4y+F2hX3hiX93HeaTiO2tryP/tnXzlfAU6U/rGHqe+evmuR4jOL+zwU6c4fb01O71Xwl4P0Xwnb+JPjhpJ0jx7JpfmWepaDBJHcaXbx+Xb2X+j/8/lfS37PXxa/4WN4bNnqWp2+peItIEYu762/1eoW//LO8j/6ZyV514x8Ft+1b4U0XxP4K16z0O5ubT7Ffi5s/tEZj8yP95/yz8u4t5AfLr2D4ffAzwf8ADvWZdZ0nQrey164j8u81K3+SS8/6aSVwZ1i8HiMB7PEfxz8TqU6mGqVKFSHvnp0LZrA8W+KbPwR4cvdd1Iyf2fp8f2i48uPzJPLrejHHFeJ/tXeJ/C+n/CDWdK8UatJpv9oW0kccenf8fMn/AFzr8wy3D/WMRTpmtCn7SfJM8c+MnxZ8L+M/7K+L3wz1n+1/E3gCSOTULKKO4t/M0+T/AFkckdfbXg7xlpvjrwho/iPTX83TdTtI7y3k/wCmcgBr43/ZE+FXi/WvDfiHXfiTrOralZeI7f7PZ6TqUkn7u3/6516R+w3qlxp3gTxH8P8AUv8Aj88Aa5caTjzPM/0fPmR1/QORYim6k8HTqfATmtKnD+HP4D6rHSlpBzS19meAFFFFABRRSHoaAPkP4qyf8LA/bW8B+FxB/oXhDRLjxFcfP+7+0Sf6Pb17J4x8Hab438P3ui6zaC+07UI/Lu4q8W+FNiNd/bD+OfifzxJ9h/s/Rox/zz/0eM19FoNuTX4PxZj6lPM17P7B7yc6fJA+PNHtdc/ZV8RXGnPOkvhy5njj0+OW7wdT/qLj/wAhyV9M+DvGuleONCTU9IvPMjy8Z42bH9JP9ys34q+G7Xxl4L1SC7077TcW8clxaf8APSOSviX9lD4r6jr3ishtV+xeIXjjz9t/1WsR/wDTx/03j/5ZyV5sqcMxw88TT+M+mw+A/tHCVK8PjgfoxIc18G/tvfE2bXfFtp4B0m6SNE8v7YfM8uPfJ/z0r7AtvGdvcaBe3Nwv2K8gikkns5P9ZHX5/wDhv4GfED9p261XxbosNgLS8u5E8y5k8vzBRkOEq4ipzume9wdh8JQxc8XmNT2cIfmer6N+zZ+z5daNH/avxFH2vy4/PlOvQRmq/ij9nz9nyw0DULnTfiLHLfxwSeQn/CRQf6yuQ/4d5/Ek3H/MF/8AAuSq3iD9hf4g6Bot5qNx/ZPlwQSXEn7+Sv1lc/s/93PsoSwlXEXWd/12PM7/AMRajo9j8Jdd0yfy9R0+xkuLTzf+u719g+Gf2zPDfizQ7J7Xz9E1H93Hrl9/yz0//nn/AKz/AI+PM/1cdfF3iETax4Z+HKW8Enm3NjcR2llH/rP9e9eseAf2Tfi14p0jaLQaBpwuI9Qjj1WTy5PM/wDIlZU6lSFf93T9w6s8ynJMZgadTGYjkqa/me6eNv2yPC2hza1cm3uL+5gd7PRD/qkuZP8Al4t/L/5d/L48z7RXyRBr11rnw4+NHiPUv9J1HUDp9xOP+mn2w16f4s/Y1+Muj+GriL/R9bsbi4/tC8sref8AeSXFeR6Hbz+Gvh/8V9L12CTSNVmt9P8A9Cuf3cnySUVPaVK/7ymcGTZbkmDwk3g8Rz1OdfcfSfh/4O/s0Xei6ZPq3iyMai9vH58f/CRmP95/38q3/wAKc/ZJ5/4qu39v+KjuP8a4rQP2DfiDr2iR3UGq6F5dxBHPH+8uK0F/4J1/Elj/AMhvQ/8Av5cVp+//AOfBWIqZSqk751UNb9nTxzpXw7+OGqeDtB1+PWvButxfaNMkjuPtEdtJ/wA86+1oMY/fdK/OHx7+zr40/Zfs9M8bXeqaVcmyv48x2Ykwn7yvrTxv8YdCj8Ei5n8QJogkgj330UnlySf9M46/MeJMsqQxdOp7Pc+Lz7LaGMr06+X1Pac/XzRvfEv4q2vgsm1S4s/tj7BIdRk8u3tP+vg5/wCWn/LOvL/g78OtS+Ivjf8A4WF4kg1bRx+8t/7J1L959v8A+mkn/POP/nnHXy/H4ln+Nfxc8I6Vp2myR+Gba8jNppNxJJJJJ+8/eXFxX6a2dsLW0t0jHQc1wYv/AISKfJT/AIh5+a4D+w6FOm/4kzREceK+dvAJ/wCEA/bm8XaOsf8AoXjDw5Fq3P8Aq/tFvJ5f8q+h5jhRXz78VbP7J+1X8DdaE/l+bcajpcg/56f6NJJXdwnXqQx/7w+RjyVFODPrilpB0FLX9AngBRRRQAUjfdP0paRvun6UAfJX7NkX/Fx/j3d/89PF8kf/AH7jr6Bjl4r5/wD2aePiB8c/+xyl/wDRYrC8bfEzxn8dvGuqeB/hDeR6Zo2mP9n1/wAYmPzI4JP+fe3/AOmlfhGZ5RiM1zepTpn01XSSue1+LviV4P8ABVif+Eg17TdIjk4/0q4SOvzj+IPw18OXfjKW48BeOfC+q6dcXHmW9j/aMdvcW8n/AEzr6B8b+Df2a/2U7izu/inqd34p8X3A83zdSeTUbmSvTvBfgb9nX9pTw55nhzT9B1Syx/q7KIW9xHX12A4TngKXuVD3Mn4go5PUnOjNnmvhXwr8SNP+GWs6l4u1W2XTk0ySOOGF/MuJP+ukn/TOvDfhd+1d4u+EPhG20LQrXSvsEYkH+kxySSSSV7z8Uf2XPF3wh8N6mfhrrupal4aNvJ53hzUn+0f+A/pV/wDZA+H/AMLviJ8J4pNT0uwvdSR5Le8+0geZ5lPCZbXw9ep7N+zPtcFmWWLA18VjKXt+d7LoeSSf8FAviaP+gF/34krN1v8AbZ+JnijTZNO8jSZTeRyW/wDo0EnmSV9yf8KK+D4Hy+G/D49wK+Y/2gvCPhjRfjT4Ht/B2naTbjT7PUNVu/s/lxx/aIx/o3/fuSvWnhK9PfEF0c84frr91lfJPud1+zr8M/A37P8AodvrPjfxLokPiaSKOKSXUryOOOzj/wCfePzK+idX8f6FBoVx/Zuu2L3MiSeRLFi4jgk/7Z/886+O9J/Zv10fZ4PiF4wuL7TpI4/9B0Szt9Gt45PM/wCfiT/WSRyVw9lawXX9ralqWu3GpxXGjx29nLJeWdvJZ+X/AMfv7uPy/tklv+8j8ySOvscPhPZ0/cPwHM85r4vEVK1Q+hfhF4n+KesfF7W/+El1200zRPtFmbPGnXH2fXLf7P5kn2f7RJ/o9d3+0t+zVoPx48JSeeI4vEFtbyfYNWiH7yKSvFdHttS8SfD7xxajQrfwt4i8yTT45dEk/wBIj1SS38z/AFkn/POS3jt469M/Zh1S1l04Tx/vbzXLSOS58qXzNOt5I/8Al3to/wDnn5cn7uT/AJaeXTr06c6ZpgMfUw9SnUpnxw37VXxc8GD+ypdcit5NP8yzkj+x/ckjpkn7avxeAx/wl/H/AGC46+lofCHhLw7+174vGqwWI07V9EttUj+2JHsjnB8uvZjJ8EVQIf8AhESfc29fFQwtSftP9oP318QZNThTf9lc91ufml45+PPj/wCJ2k3Oia54jmvdPl/eSWYto69+8V/Avwb4j+HvhnxZr3iaDwrqBsI4pL7935cn7uuw/a/8Q/DO2+Gx0jwna6He65qF3HbWcOjG38zNeCasmm+Fda0a18T3dj4t8ZeXHvj1af8A4lWkR/8APOTy/wDlpXkY7A1PaU/3h6zxMM0oU6mX4f6vNX0tud98Hfif8Cvgpf3F1o8+u+KtRk8yO41aLT7iXy469+8DfthfC7xtf/Y7TXfsN5/zy1WP7NJJ/wB/K838HftVa54YP9nHQ/AOqad5f7v+yfEkdn/6MrX8T+PPB3xa0S4s/FPwRv8AUzL9+TSpbO48v/tp5kdTX4eweNXtPafvD85x2HxVfETqYynOZ9RZF1+/E/7uvnX9p+T7L8QPgFd+f5ezxpHH/wB/K8o+HHxT1L9nr7MXu9W1j4SSahJpV5/bccn9o+H7j/5Hr0/9o+L+3vix+zza2n+nf8VJJe/9s44/Mr5/LclxGX5tTfP+7Pn6lD2Ez7QHQUtIOgpa/bj5IKKKKACkPSlpKAPzR+L3xJuvhb8V/j34X8Ofu/EfifUNOTS4/wDprcW0fmV7T8XNHs/2V/2RLfQ/DV3qWiXsklvZf2tpEfmSi4k/5eP3lcn+1b8MLcftm/APxaMeXf3kmn3kn+3B+8i/9GGs79sz4/6R4+8JXvgjQdIvtX8u8guY9SiH+hXH2S5j+0/vP+mdeLTp08O6lT7Z9ZJQxnsKdM+bvG3/AASq+KdwbrWoPGGkeKtRn/eJ9qkuI7i4rZ/Zw/4Jy/EXwd4/sfEvijxLb+BLPSJPtE8mk3vmXBq7rf7Q3xTv/iRb+OZ9Mj+xWGoSeFtM0j7R+7t7ySOsDV7nxy3g3xvpWtajGTca3HZ62ftH7y8uJI4/L/7Zx0qmZ+z+we5Q4VqYn93OfIfq/F4i0i7+zQw6lbymePzI/wB5/rI6/Mv9rbwxoehfFC61bwxqPmadq8sn2uO2k/dwXEdc/wCKNX8f6J4m1TWLvVsX/h63j0d7iJ/3cEdx/wA+8dYd7FB/wofwj5/+s/t+8k/nXiY7GQxdPkmfpXC3C88kxlPFe09pTn7hxvm3f+k+RcX8nl/6zy5JP3ddf8Hjb3vjuz024/d22r29zpXmSf8ALOS4jrC8N+LdQ8L3/nWw82OT/WW//LN67mxsPDfxDUT6Vdnwv4iEnmRof3ccklfLLF+zqc8/gP1/PcL7PD1KcqXxn09rfi3/AITfT7b/AJ56heR22qXttHJJc2ckf/XPzPLkjkrJ0nwH4k0bULLXdF8Lyf21bySf8s7jy4724/dx/Z/9X/ocf+svP+ekleH3Hwr0n4jeLP7a1XRZ4/iDJbx2+oeG9N1D+z49Yk/6CNvcf+jI64uPUNJ8EW97puveKNa0i9+0SeZF/wAJpcR/6P8AvP3fl1+sYfGLEYfnoVD+A83y+phMZUpzpn3B4U8UXHg610a0s9S1a9tPt8ceny65dyW8l5bx+X9tvbmSTzP3f/POvGPiH8X4NBPxB0231afytPk+z6X4o0STy7fS4/8Aj8kj8zzJP+WnmRx+X/q/9XXkEkX9jah/wi/n39je6h5eq/23qV5JeXOn2f8Aq/Lt4/Lkkk+0eZ+78v8AeR1Y8OR+KB/omtWscl75cn9l+G/L/eSR/aP3dxqv/TOOT955f/LSSs8RjKeHp/vDPL8BiMfiFQoUzD+MuvXHjHxbcnUjPcS28cdvnUpPMkjj/wBZ/wCQ/M/eVwt74YmsYLO6utKex8//AFHP3/8AtnXX6raW/wAPNb3z3n/CR66fMkvDJJ+7En/2yud1rXdS12f7VqT+ZJ/zy/5Zx1+XYjETqVPaH+guQ4H2eDw9B0vcgjQ8H2k2kW9zqunW/l6ibiOzs5I4/wB5HJJHJ5nl/wDXOOut8L/C/wAN+KNP0q7n8UatF5kkn9oSfY/Mkt5P/tlafw48If8ACZfCzVDBdWFjJo+vR3En9pXn2eKSP7PJ/wAtKw9J8Ca7o1x/yEvC19H/AMtI5dc8uOSvToXfs51PgPis2xqqVMRTwdb2dSmdFF8AvDd1/ZXn+N9Ti8zzPtnmaX/x51hS/szeGLqe3E/jG4izeSRHytDk/dx/89K9A0Swnuv9frvw/wBI/d/6uTxJ5n/tOi68O/ZLi3/4uv8ADG2/66XnmV78KNCH8OB+QV80zyo+TEVit8M/EQ0Hwr4u+Fl2PDp8O293Hp15HJ5n2nV5Lj/l4j/651q/sparrXjr9pbwP4Q1Z55ZfhZYaoPtp/5eP+XaP/yHJWT4F+G2jafrl7af8Lw+HN9/wkGqWdxJFFbiS58yO4/1dv8Ava+gv2KfDBl+Nvx98Xj/AFdz4gj063/7Z/6yu+hT9p7NngZliqfs6k4Q1PtYdBS0UV7Z+eBRRRQAUUUlAHz/APtb/DPUvH/wwlu/DUYk8V+HLyPXtLwP9ZcW/wDyz/7aR5jr89NO+E3x8+Kltbat4Q02MeF5LjUJNL/eRxyR295ceZJX7DHpXzL4g8KeLfgH4pvfEfgXTv8AhKvBmqXf2nVPCUXlxSWcnSS5s/8A2pHXNUp+0PbwOZVMH7lM+KB+yL+0w1v5E2nReV/aH9q/8hC3/wCPip7n9kX9oW8nuP7T04XouLiO8u/+JhH+8kr9Dfhx+0X8P/ihpn2vRdetB/z8WV7J9nuIJP8ArnJXUa18VPB/hzT5bvUvEmlWUSf8tTcx15tTA06m59TT4qzSnP8Ah/gfmd/wyL8dtQF613pwNtP5ct4bnUP+PiSvNPE8mpaNY2XhLUfLzok9xJcGKTzI5JJK+t/jx+37o15pd7oPw5n869k8yKTVpI/9Hjr4mtrqe6HP/f2T/WSV8hmUKdP93QP6C4Dnmeafv8zp8kPsEVSx5/74/wCWkX+sjqKrunXP2G/t7op5nlyRyeX/AM9K+ZP3rE29kes6f461fTtPtLTxxos97pUhjNpeCP8AeRyV1esz+KNQ0UzaVqOm+P8ASrby5PsWuWcdxcQeX/00rroINB+KvguO3l1CMDEf+rk/eR15ddavp3wF8R+R4cf/AISCWe3k+12Xmf6uT/lnJXHhMXXqTdPCQ/eH82ZnDCV/aVKtK00aul32rLottqOqLpXw40uP955WhafHb3Ekf/XT95JXN6v4s1XXtOl03wVpU9jpUaSSXl7/AMvF5J/z0/7aVesLu1+NfiOW08SXT+FtRjjj+x2P/PST/lpcV6lIvhz4OeDvs/2qA/u5NnPmSTyVrjcdXp11Txf8QMvjgaXs6uHpXqHyKP8AUVGetXL2X7VcXE//AD0kkk8v/nnVM9a7D+ksPb6ueifCLV9N/tHVfC+tWljcaNr9vHxqX+r+0R/6uSrt74Ku7C/uLTUvDfwp03ULfy/Msri4kjkrzKOust/G1p4p0+203x5BITBH/ofie2j8ySOP/p4r2cHXfJ7OZ+O8SZL7LF/W4fBPc6GLw8D/AMwX4N/9tburMnhie6t/+QL8B/8AwMrk5/gTaa//AMgP4h+EL2P/AKeZRbyRx0aJ8HfBGjeI9L01Nd/4Wn4iuJP9D8N+HI/Likk/6eJK+joc9TQ/MMy+r4dXhM9Y8JeGLvwRb/8ACb/8I38OL7ypPs/huPwdHJcSXmsyfu446/QT4EfDW3+EHwx0Xw98st5HGJNQuf8An4uZP9ZL/wBtJK8q+BH7NV5YanpXi7xzb2EWpafH5eh+G9JT/iXaHF6/9NLiT/lpJX1DtyMV9Nh6fs4H4bmeO+sO0CeikFLXSeGFFFFADfSsq+1G00ewuLq8kjt7GKN5JpZf3aRp71o9BXh37Sd3Bd+HfCOhT2n23TPEniOz068jByJIP3k5H/A/KrjxFf6vSnU7GkIc5nSftSXGvan9k8C+Bda8VW//AEF5f9D07/v5JVG5h+PHiT7NJceJfC3gyL/lpZW1nJqMn/fyTy69YMWP3FYHjLXZ/CXhy91ODTZNX8v/AJdvNjt//Iklfi9Ti/H4/EfV8JA9dUqdP94fL8v/AATe8Iax4kvde17xfr2r6jeXElxcSxeXb1S/4Ye+Ct940ufDcF3rt9rVvH9ok/0iSSO3ruLL4xfEHxlB4iNpceBPCMej3kkfmXWoSXtxJHHH/wBs/wDWV5B4O+NvjC71DRfFH/CyfC2h2XiTR/7Q1SX+x/Mjs5Lf93H5lenQoZvU5/b1ztp5jX5/3czq9X/4JveG/wDmG+L9Wtv+ecUkfmR1514l/YM+IOgj/iTalput/wDTOX/R5K9b+E3x3+IXiTxJ4U02fxL4W8Qya5cXnmWUWnyW8lvbx/8ALxXovxI/aPHw18aW+h6n4Xkks7iSS3s9R03ULOT955f/AC0jkkjkjrhnQzaFWFOn+8Ppst4zzfL9Kdc/PfxZ8NfE/gCfZ4g0O700f89R+8jrmPK5/jr7u+A/7SFn8QfHGtaF4w1WOyP2eP8As+y1qz/s77R5f/LT95/z0r0nx3+yh8NfGolu7rQ47GST/l9t3+z1rivaYCpyYimfreVeLjt7PMKB+ZsUv2T9/BPPHJ/0zk8uruieRdape+fdyaZeyfvI5IpPL8yP/tp/rK+1dS/4J9aHczZsPEmq2Cema525/wCCfLXf7j/hMMiPoXtIzJHXdk2fYTK8XDF1Dq4g4syHiDATwtOt7Op6HyRq2lWlhqFkYNSkvtR/eSSSyyeZJHHVe5mJxPPPPJ/10k8yvsCw/wCCdNrbNj/hNbj95J+8MdnHHJXe6B+wZ4F0dc6jd6lq5/6aSfZ//RdZ57n+BzDFuvTOHh/izJOHMBDCuc6lQ/P3y8/369H8F/ALx/49+zz6X4ccWZ/5eLmT7PHX6LeEfgF4F+H4/wCJN4bgi/6af6yStLxz8RPB3wp0j7X4k1zSdDs/+nmTy6+b+u1aj5MJT5zLM/FirUXs8vo8nqfI/hz/AIJ9a1fjOueJ0sh/zz06PfXpun/sDfDW1g/4mP8AaOpSf9NbspVTxR+2tALe4Hg/wLrWrxx3lnp0mra3/wAS62t7i4/1f+s/efvKv/F74s+JPh14/wDB+m6z4o0jSI/EfmW8dlFp8lxJbyeXJ/pH/bOSvVqZbmtT2cOfkPyjH8ZZvmM/3uIJn/4J9/CO566Vc/hfyf40sP7BXwtsLj7Xof8AbOiatH+8jvbW/k8yOvGf+F2/FTw5oek+JNd8dR/2LJo95rN5JFpccdx+7k8uPy4//RlaOi/Hf41H+yp9S17w1qcVxJHZ3ljLonl/vP7OkvK6oZJm9P3/AKweFUzTF1P4lQ9nt/hp8XvCQP8AwiHxe/tiL/WRxeLdPjuf/Ikfl1oD9oL4g/DmC4m+KngWP+wY+bjXtAuPtFvbx/8ATSOuk/Z9v7rWfg/4U1a70LTfDUlxb/aI9N02TzI7eOSu41/S4Na0W+tLgCSK4t5I54/+ekdcq4nx2X4z6tUqc5xVFCprM7bTb611jT7e7s5xLbXEaSxyp/y0StNhwK8J/Y2lnP7NXgO3uP8Al3shbj/rnH+7/pXudftNKr7Smqh4E4ezfIS5ooxRWlxWIq85+MQt/sPhzz4PNP8Ab9l5H+xJ5lejVxfxMkt/7EsvP6/2pZeX/wBdPtMdeTmn+51DWn/ELMoyK87+KfgZ/iP4UvtB+0fYt7xyR/u/MTzI5Y5I/MH/AC0j4/eR16IQD1ryfx9+0f8ADr4c/uNc8UabFe/8+Ucn2mX/AL9x1/N2BWMVX2lOme57OdT3KZ5rpn7OupeINW1W48SW+kg3PiiPVby4jt/+Pu3jt44/9H/55+ZXo+r/AAR8Nf25pV3/AGbbxaDp+j3mlf2bFb/u/s8lcZbftP61r/8AyK/wh8YatF/z0uvL0+P/AMiVV1/9pX4keDdEvdW1z4H6lZaVbx+ZLKPEFvJ5cdfWTrZtiJ8ntBQws0ami3+k2nxO8CQfak1OS30+4s7C9j8s3Mkn/TxH5cfl+XXK+LP2dNSPjPwf9ntNM8VaBH4gvNV1CPUrf955kkcnl/aP+ekccldxpvxPnsLf+1vEnwo17wsbvy/Mvre3jvf3f/XS38ySu08G/F/wL43ubi30LxJY3N75nlyWXm+XcRyf9c61qTzfK69OpCmZwgj5L8bfCX7B9t8IazaXGuXun6Pp8nm6bp8d5H9okvbi4+z+XJ/y7yf6us7wL4I134VeLPB+heJPHWvfDm9vPD+oa7qEem3n2i38z+0Y47K38uT7R5nl/aK+9orWD/Sf3H/TOT/ppXmHxH+A/hv4g67pWu+R9h8VaPHFHp+o/wDPv5dxHcR/u/8ArpXdQ4u9p+7xtMidM8K1/wCOXxB8EfYv7B+Jng/4gf8AEws9K/sS50/7FqP7y4+z1Y8P/tR/FO71v+xpvBHg+LUZfEmoeGbfOuSRRyXFnFJcSSf6v/j3r2nVP2etB1y/0XXjB/wj3i/T7yTVTq+k/u5PtlxH5dz/ANdPMrj/AIe/sh+E7CC2u/G9p/wlOpaXrmsahZXMskkkktveSf8ALx/z0kr0qeZZDUp/vKZFpnFaR+1j8RdQ8AaV4vufDfgDRNJ1C4uLezk1vxJcRySSRy/Z5P8AlnJXPQ/tYfEzxwNKGkXPgPSbLUfF8fhC0kgFxe/aLg+X/pEf+r4jr2f4F/BLRtL+BvgPw34k0zSdTvvDdxJeWflnzI7e88yTy60fhT8B7Tw7P4r/AOEk03SdTFx40vPFOlny/tH2fzPL8v8A1n+rkj8usv7VySnz2pmvIfOXjb4gfEHUPBmsz698U9a03xD9t1jSvDlj4T0+O3ttQvLPzI47fzP3n+srd+HPwgg8MftDeELO78HwWOo6Pocmof2lq2ofaJdckkt4/wDnp5n7yO4r6B0j4K2b/Di98NazeCYSa3eazZ31t+7ks7i4vJLgf9tI5JK6++8K6bcjSNR1eCO9udDH2i3vZB5ckc//AC0k/wC2n/LSo/1ioU4Tp4ZEezZ85/GL4N+KNG8N6tdwWkfi691zxZp9xeX3/LzHp8d5HJbW/l/9M69z+JWq+G9BnsdS1rR/t0sf2g6fqUtn9oj0+48v/np+88vzKz9S/aM8Hi//ALN0a7k8XarH/rNO8N28moSR/wDfuvPfir8ffiZ4I8KXuuD4UT2OnReXHHJrWoW/mSSSSf8APOOSSua+bZn7NzplwoKcyX4S/DXSfi1+z5baL430G0vpPMvI45ZLP/npJJ/pEfmV2k37PPhe5xqYt/8Aiq49Ik0q01eX/rn5f+rrkbbxR+0qba3/AOKJ8Ef6uOTy5NXuPMqj4h/aF+Jnw60691Lxt8KJI9Js4/MvNW0XW7e4jjj/AOuf7uSuHELM517U6n4m0KHtD3jwJ4XHgjwRovhsT+b/AGZZx23m/wDPSujk/wBRXgPw4/bL+GfxFFvbjXf7H1GTy/Lstaj+zyyV7rJNBdW/yf8ALT/V/wDTSvja2DxlPEqpXpmvs50375x/7IP/ACb14P8A+uUn/oySvaa8V/Y+/wCTe/CH/XvJ/wCjDXtVf01g/wDdqZ4OK/j1Caiiiu85SBcHmvE/2qfF2m/Dn4XSeMNT8+Sz0O/srkxW3+sk/wBIjj/9qV7UpwAK8Q/bB+G2pfFz9nfxf4X0PD69cR29xZxk+X5ktvcxXA/9F1yYqEKtKcJm+HmqdSE6h8heNfGPxT+L2n+MD4k1a4+H2laf4Xk8TafoGiSeXcXFv+8/4+LivLfjp4E0LwP4A0r+xdNjsf7Q8J6fqN5e/wDLSST7Zb16drfxd0LXdb+Iv2uf+w9Vt/hpHpV5ourf6PcR3v7yT7P+8rJ+LPhfTfG2h/ZPtfmeX8M7O4/dyf8ALxbyR+XXw0KfsnyezPv8B7k/7h9SaF+0r8KPCfhTRrfUviDoscsdnH5n+keZXF/HH9pr4UfED4KeL9F03xlpmpXtxp8kcdl/q5JJK+UvFvhP4NeCP7Z023/syTUbzwZHJp8XmSXkkmqSf9/K9a+Gn7H138XvH3h3xTqXgkfD7wXZ29nJJZ6lH9n1W7uI/wDpn/yz8ysMJw/QniPrEDixEMJT/eTqH6KeFE/4pTRR6WkX/ouuQ+IHwQ8DfFB4rjxJ4Y03Ur2OPy47yS3H2iP/AK5yV6FbRJFAEHSOpnGcGv0WdJVNGfFe05HzwPnc/sx3HhkGb4ffEHxN4V/552Vxef2pZf8Afu48yo49B+PehXEAhn8F+NLHvc3QuNGuP/If2ivovIoryK+S4PEfHTOv61M+ZZviR8Xobj7LJ8CL/Uf+nix8UWfl/wDkSSOtKP4nfED/AJb/AAP8URf9ctR0uT/25r6H2j0FG0egryqnCmWVP+XZr9bj/IfMdj458c6P9p/sX9nzXY/Mk8yT/ia6Xb+ZJ/4EUkXiv47+J/tNvp3wl03wt/zzuvFniSOSN/8AtnbfaK+nQuOwFGwDvRT4Uyxf8uzN4v8AkgfNcXwn+M3inB134l6b4aspf9ZZeHNGxJ/4ESSSVqaf+yH4LdbaXxLc6945kTt4l1F7iB/+3cbIv/IdfQNNOCete1QyvB4f+HTE8XW+wYvh7w7o3hfT7bTNJ06306xto8QW9tH5cccdeHft13P2D9m/xHP/AM8ri3f/AMmBX0WeNtcz4+8E6b8RvBmr+F9Xg83TNUt3triP/pnXdUpqdP2aMKdTkqQmz5Yf9v34NaPb28c/iSS+k+zxxyfZrOSvPvjr+2r8LPin8DfHHhvSdcni1a40+SO0jubfy/tElcv42+AfiX9njw54i03UvCH/AAmfhS8t7Ozt/Eegaf5lzb28f/P7Z/8ALSvKPFnjL4H+MtV8V/ZTpliJNQ0eOz+02clvJ5cf/H5X5/8A2HTw9f6x7N3Pu6FHAVP3kKhv2fg7Sr/4K+N59S023vr2w8P+Ho7CSSP95HJXUeLPGPjD9lHxJ4w/4Q/WZL7wZ4f/ALPjk8N63JJcfvLz/nnJWRrPxQ+H1rpXxZ0bTvEtv/Z+oanp1vpkVr+8kkt4/L/1ddX48+HXij9pPxX4v8N+HPCGtab4c8SX+n3N54o1qzuNPjt7e3j/AOWcVxHH5lbUKeIq1eSpT9w9DF1MPOftPsH2T+x83/GNPw7uDx9r0e3uJP8AfkFe1R/ermvAngzTPh74I0Pw3ov7rTdJtI7O3/jxHGMV0ankmvv6cPZ07H5nUn7SpOZYzRTaK0uZD6QilpD0pjPPfHXwg8EfFC3t/wDhL/Cek+JfL/1f9pWcdx5deY/8MDfAb7R5/wDwrrTf/Ai4/wDjlfRMZOetOAPrWdSnzmqnVhtM4DwR8Evh78Osy+FvBGheH5T/AMtNN0+CKT8xXolLRVpWMtwooopgFFFFABRRRQAUmKWigApMUtFABRRRQAmKi/c+1TUUAQ+TnsKlAA7ClooAKTFLRQAUUUUAf//Z" alt="image"></span></td>
    <td colspan="3"> <p style='margin:0cm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:2.25pt;margin-right:  3.15pt;margin-bottom:.0001pt;margin-left:3.15pt;text-align:  center;line-height:14.1pt;'><strong><u><span style='font-size:19px;font-family:"Nirmala UI",sans-serif;'>लातूर &nbsp;वाघाळा&nbsp;शहर&nbsp;महानगर&nbsp;पािलका&nbsp;लातूर </span></u></strong></p>
                <p style='margin:0cm;font-size:15px;font-family:"Calibri",sans-serif;margin-right:14.75pt;text-align:  right;line-height:10.25pt;'><strong><em><span style="font-size:16px;font-family:Consolas;">No</span></em></strong><strong><span style='font-size:16px;font-family:"Nirmala UI",sans-serif;'>.&nbsp;</span></strong><strong><em><span style="font-size:16px;font-family:  Consolas;">MHLAT{{$data->survey_app_no}}{{date('mY')}}</span></em></strong></p>
                <p style='margin:0cm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:0cm;margin-right:3.2pt;margin-bottom:.0001pt;margin-left:3.15pt;text-align:center;line-height:15.75pt;'><span style='font-size:16px;font-family:"Nirmala UI Semilight",sans-serif;'><b>व्यवसायिक आस्थापना सर्वेक्षण नमूना</b></p>
                <p style='margin:0cm;font-size:15px;font-family:"Calibri",sans-serif;margin-top:3.25pt;margin-right:  6.65pt;margin-bottom:.0001pt;margin-left:3.15pt;text-align:  center;'>(महाराष्ट्र प्रांतिक महानगरपालिका अधिनियम, १९४९ चे कलम ३८६ व प्रकरण १८ अंतर्गत)</p>
        </tr>
        <tr>
            <td width="100%" colspan="4" style="background: rgb(242, 242, 242);" align="center">
                <strong><span style="color:black;">Application For Trade License</span></strong></td>
  </tr>
  </table>
  <table width="100%" border="none">
  <tr>
    <td width="5%" align="center">1</td>
    <td width="25%">Name of Establishment</td>
    <td width="40%">&nbsp;{{ $data->establishment1 }}</td>
    <td rowspan="3"> 
    <label style="z-index: 1000; position:absolute; margin-top:6.5%; margin-left:16%;font-size:12px;"><b>
      Latitude: {{ $data->latitude }}<br/>
      Longitude: {{ $data->longitude }}<b></label>
    <img src="{{ asset('images/serve_photo/' . $data->photo) }}"
        style="height:120px;width:100%;" alt="" /></td>
  </tr>
  <tr>
    <td width="5%" align="center">2</td>
    <td width="25%">Name of Business Owner</td>
    <td width="40%">&nbsp;{{ $data->bussiness_owner1 }}</td>
    
  </tr>
  <tr>
    <td width="5%" align="center">3</td>
    <td width="25%">Name of Contact Person</td>
    <td width="40%">&nbsp;{{ $data->contact_person1 }}</td>
   
  </tr>
   <tr>
   			 <td width="10%" align="center">4</td>
            <td width="90%" colspan="3" style="background: rgb(242, 242, 242);" align="center">
                <strong><span style="color:black;">Address</span></strong></td>
  </tr>
  <tr>
    <td width="5%" align="center">4.1</td>
    <td>Shop/House No.</td>
    <td colspan="2">&nbsp;{{ $data->shop_house_no1 }}</td>
  </tr>
  <tr>
    <td width="5%" align="center">4.2</td>
    <td>Name of  Building</td>
    <td colspan="2">&nbsp;{{ $data->bulding1 }}</td>
  </tr>
  <tr>
    <td width="5%" align="center">4.3</td>
    <td>Lane/Street Name</td>
    <td colspan="2">&nbsp;{{ $data->street_name1 }}</td>
  </tr>
  <tr>
    <td width="5%" align="center">4.4</td>
    <td>Locality</td>
   <td colspan="2">&nbsp;{{ $data->locality1 }}</td>
  </tr>
  <tr>
    <td width="5%" align="center">4.5</td>
    <td>Ward/Prabhag Name/ No.</td>
    <td colspan="2">&nbsp;{{ $data->prabhag_name1 }}</td>
  </tr>
  <tr>
    <td width="5%" align="center">4.6</td>
    <td>Zone No.</td>
   <td colspan="2">&nbsp;{{ $data->zone_no1 }}</td>
  </tr>
  <tr>
    <td width="5%" align="center">4.7</td>
    <td>PIN Code</td>
    <td colspan="2">&nbsp;{{ $data->pincode1 }}</td>
  </tr>
  <tr>
    <td width="5%" align="center">4.8</td>
    <td>Whtas App No</td>
    <td colspan="2">&nbsp;{{ $data->wht_app_no1 }}</td>
  </tr>
  <tr>
    <td width="5%" align="center">4.9</td>
    <td>Email Id</td>
    <td colspan="2">&nbsp;{{ $data->email1 }}</td>
  </tr>
  <tr>
    <td width="5%" align="center">5</td>
    <td>GST No.</td>
    <td colspan="2">&nbsp;{{ $data->gst_no1 }}</td>
  </tr>
  <tr>
    <td width="5%" align="center">6</td>
    <td>Year of Starting of Business</td>
    <td colspan="2">&nbsp;{{ $data->year }}</td>
  </tr>
  {{-- <tr>
    <td width="5%" align="center">7</td>
    <td>Nature of Business</td>
   <td colspan="2">&nbsp;</td>
  </tr> --}}
  <tr>
    <td width="5%" align="center">8</td>
    <td>Type of Business</td>
    <td colspan="2">&nbsp;{{$data->type_of_bussiness_id=='Hotel' ?$data->type_of_bussiness_id : '' }}  {{ $data->bussiness_type1 }}<br/>&nbsp;
        {{-- No of Non AC Room: {{ $data->non_ac_room }}<br/>
        &nbsp; No of AC Room:  {{ $data->ac_room }}<br/> --}}
      </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>If any...</td>
    <td colspan="2">&nbsp;</td>
  </tr>
   </table>
  <table width="100%" border="none">
   <tr>
   			 <td width="10%" align="center">9</td>
            <td width="90%" colspan="3" style="background: rgb(242, 242, 242);" align="center">
                <strong><span style="color:black;">Enter the Registration No. Whichever is Aplicable</span></strong></td>
  </tr>
  <tr>
    <td width="5%" align="center">9.1</td>
    <td>Shop & Commercial Establishment
ACT 1956</td>
    <td colspan="2">&nbsp;{{$data->type_of_licence_id=='Other' ?$data->type_of_licence_id : '' }}{{ $data->bussiness_reg_type1 }}  <br/> &nbsp;License Name: {{ $data->licence_name1 }} 
       </td>
  </tr>
  <tr>
    <td width="5%" align="center">9.2</td>
    <td>License No.</td>
     <td colspan="2">&nbsp;{{ $data->licence_no1 }}</td>
  </tr>
  <tr>
    <td width="5%" align="center">10</td>
    <td>Number of Employees Working as on
date</td>
     <td colspan="2">&nbsp;{{ $data->no_of_employee_working1 }}</td>
  </tr>
  <tr>
    <td width="5%" align="center">11</td>
    <td>Area of Business in square Feet</td>
     <td colspan="2">&nbsp;{{ $data->area_of_bussiness1 }}</td>
  </tr>
  <tr>
    <td width="5%" align="center">12</td>
    <td width="35%">Year of Starting of Business</td>
     <td colspan="2">&nbsp;{{ $data->year }}</td>
  </tr>
</table>
<label style="position:absolute; margin-top:6.5%; margin-left:80%;font-size:15px;"><b>Signature Of Establishment Owner</b>
</label>
</body>
</html>